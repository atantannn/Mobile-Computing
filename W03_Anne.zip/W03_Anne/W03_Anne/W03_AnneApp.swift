//
//  W03_AnneApp.swift
//  W03_Anne
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_AnneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
