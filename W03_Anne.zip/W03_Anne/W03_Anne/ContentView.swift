//
//  ContentView.swift
//  W03_Anne
//
//  Created by student on 25/09/25.
//

import SwiftUI
struct ContentView2: View {
    var body: some View {
        VStack{
        Text("View 2")
        }
        
    }
}
struct ContentView: View {
    @State private var count = 0
    @State private var nama = ""
    @State private var totalCount = 0
    var body: some View {
        NavigationStack{
            VStack{
                Text("🏡 Home Screen")
                    .font(.largeTitle)
                NavigationLink("Go to Details"){
                 DetailScreen()
                }
                NavigationLink("Show Item"){
                 ItemScreen()
                }
                
            }
//        TabView{
//            HomeView()
//                .tabItem {
//                    Label("Home", systemImage: "house.fill")
//                }
//                .badge("2")
//            SearchView()
//                .tabItem {
//                    Label("Search", systemImage: "magnifyingglass")
//                }
//            ProfileView()
//                .tabItem {
//                    Label("Profile", systemImage: "person.circle")
//                }
//        }
        
        
//            ContentView2()
//            Text("Hitung : \(count)")
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
//            Text("Nama:")
//            TextField("Isi Nama", text: $nama)
//                .textFieldStyle(RoundedBorderTextFieldStyle())
//            HStack{
//                Button("-"){
//                    count += 1
//                }
//                .font(Font.largeTitle).bold()
//                Button("+"){
//                    count += 1
//                }
//                .font(Font.largeTitle).bold()
//            }
//        VStack {
//            Text("Parent View")
//                .font(.largeTitle)
//            Text("Total Count : \(totalCount)")
//                .font(.title2)
//                .padding()
//            
//            SwiftUIView(count: $totalCount)
//            Spacer()
//        }
//        .padding()
//        .background(.green.opacity(0.8))
        
    }
}
    struct DetailScreen: View {
        var body: some View {
            VStack{
                Text("Detail Screen")
                    .font(.largeTitle)
                Text("You come from the home screen!")
            }
            .navigationTitle("Detail")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    struct ItemScreen: View {
        let items = ["Tomato", "Papaya", "Pineapple"]
        var body: some View {
                List(items, id: \.self){item in
                    NavigationLink(destination:ItemDetailScreen(item: item)){
                        Text(item)
                    }
                    // bisa di klik
                }
            .navigationDestination(for: String.self){
                item in ItemDetailScreen(item:item)
            } //untuk tujuannya kemana
            .navigationTitle("Items")
        }
           
    }
    struct ItemDetailScreen : View {
        let item: String
        var body: some View {
            VStack{
                Text("Welcome to item Detail!")
                    .font(.title)
                Text("You selected \(item)")
            
        }
            .navigationTitle(item)
            .navigationBarTitleDisplayMode(.inline)
    }
}
//struct HomeView: View {
//    @State private var textKu = ""
//    var body: some View {
//        Form{
//            VStack{
//                Text("🏡 Home!")
//                    .font(.largeTitle)
//                TextField("Name", text: $textKu)
//                    .border(Color.blue)
//                
//            }
//        }
//        .padding()
//        .background(Color.pink.opacity(0.2))
//    }
//}
//
//struct SearchView: View {
//    var body: some View {
//        VStack{
//            Text("👀 Search View")
//                .font(.largeTitle)
//        }
//    }
//}
//struct ProfileView: View {
//    var body: some View {
//        VStack{
//            Text("Profile")
//                .font(.largeTitle)
//                .fontWeight(.bold)
//            Spacer()
//        }
//        .padding(.top)
//    }
}
#Preview {
    ContentView()
}
