//
//  SwiftUIView.swift
//  W03_Anne
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct SwiftUIView: View {
    @Binding var count: Int
    
    var body: some View {
        VStack{
            Text("Child View (CounterView)")
                .font(.headline)
            
            HStack{
                Button("-"){
                    count -= 1
                }.buttonStyle(.bordered)
                Button("+"){
                    count += 1
                }.buttonStyle(.bordered)
            }
            
        }
        .padding()
        .background(.red.opacity(0.8))
        .cornerRadius(10)
    }
        
}


