//
//  ContentView.swift
//  W02_TH To Do List App
//
//  Created by Jennifer Alicia Litan on 20/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var mytasks=["Practice Piano", "Laundry", "Workout"]
    @State private var newtask: String = ""
    @State private var isOn: Bool = false
    @State private var progress: Double = 0.3
    var body: some View {
        VStack(alignment: .leading) {
            HStack{
                Text("To-Do List")
                    .fontWeight(.bold)
                    .font(.largeTitle)
                    .padding(.top,20)
                Spacer()
            }
            .padding()
        }
        HStack {
            TextField("Add new task", text: $newtask)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(10)
                .cornerRadius(10)
            Button(action: {
                if !newtask.isEmpty {
                    mytasks.append(newtask)
                    newtask = ""
                }
            }) {
                Image(systemName: "plus.circle.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
            }
        }
        .padding(.horizontal)
                    .padding(.bottom, 10)
        List(mytasks, id: \.self) { task in
            HStack {
                Text(task)
                Spacer()
                Toggle("", isOn: $isOn)
                    .labelsHidden()
            }
                }
        VStack(alignment: .leading, spacing: 10) {
                        Text("Today's Progress")
                            .font(.headline)
                        ProgressView(value: progress)
                            .tint(.green) // warna progress jadi hijau
                        Text("40 / 100") // angka statis
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
        }

#Preview {
    ContentView()
}
