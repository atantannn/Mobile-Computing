//
//  ContentView.swift
//  W02_TH To Do List App
//
//  Created by Anne Tantan on 20/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var mytasks: [String] = [
        "Practice Piano",
        "Laundry",
        "Workout"
    ]
    @State private var newtask: String = ""
    @State private var done: Set<Int> = []

    
    var body: some View {
        VStack(alignment: .leading) {
            HStack{
                Text("To-Do List")
                    .fontWeight(.bold)
                    .font(.largeTitle)
                    .padding(.top,20)
                Spacer()
            }
            .padding()
            }
            HStack {
                TextField("Add new task", text: $newtask)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(10)
                    .cornerRadius(10)
                Button(action: {
                    if !newtask.isEmpty {
                        mytasks.append(newtask)
                        newtask = ""
                    }
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 10)
            
            List {
                ForEach(mytasks.indices, id: \.self) { index in
                    HStack {
                        Button(action: {
                            if done.contains(index){
                                done.remove(index)
                            } else {
                                done.insert(index)
                            }
                        }) {
                            Image(systemName: done.contains(index) ? "checkmark.square.fill" : "square")
                                .foregroundColor(done.contains(index) ? .green :.gray)
                                .font(.title2)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        Text(mytasks[index])
                            .strikethrough(done.contains(index), color: .gray)
                            .foregroundColor(done.contains(index) ? .gray : .primary)
                        Spacer()
                    }
                    
                    
                }
                
            }
            .scrollContentBackground(.hidden)
            .background(Color.white)
            
            
            VStack(alignment: .leading, spacing: 10) {
                Text("Today's Progress")
                    .font(.headline)
                ProgressView(value: mytasks.isEmpty ? 0 : Double(done.count) / Double(mytasks.count))
                    .tint(.green)
                Text("\(done.count) / \(mytasks.count) tasks done")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
            
        }
    }




#Preview {
    ContentView()
}
