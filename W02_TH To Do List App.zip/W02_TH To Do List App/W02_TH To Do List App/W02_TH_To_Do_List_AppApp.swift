//
//  W02_TH_To_Do_List_AppApp.swift
//  W02_TH To Do List App
//
//  Created by Jennifer Alicia Litan on 20/09/25.
//

import SwiftUI

@main
struct W02_TH_To_Do_List_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
