//
//  W04_AnneTests.swift
//  W04_AnneTests
//
//  Created by student on 02/10/25.
//

import Testing
@testable import W04_Anne

struct W04_AnneTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
