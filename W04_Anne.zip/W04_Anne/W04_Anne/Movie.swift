//
//  Movie.swift
//  W04_Anne
//
//  Created by student on 02/10/25.
//

import Foundation

struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let genre: String
    let description: String
    let imageURL: String
}



