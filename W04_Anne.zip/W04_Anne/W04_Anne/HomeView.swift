//
//  HomeView.swift
//  W04_Anne
//
//  Created by student on 02/10/25.
//
import SwiftUI
struct HomeView: View {
    @State private var searchText = ""
    @State private var movies: [Movie] = [
        Movie(
            title: "Frozen II",
            genre: "Animation",
            description: "Elsa the Snow Queen and her sister Anna embark on a dangerous journey far away from the kingdom of Arendelle to discover the origin of Elsa’s powers.",
            imageURL: "https://upload.wikimedia.org/wikipedia/en/8/89/Frozen_II_%282019_animated_film%29.jpg"
        ),
        Movie(
            title: "Encanto",
            genre: "Animation",
            description: "The Madrigals are an extraordinary family who live hidden in the mountains of Colombia in a magical house, in a vibrant town, in a wondrous place called Encanto.",
            imageURL: "https://filmspot.com.pt/images/filmes/posters/big/568124_pt.jpg"
        ),
        Movie(
            title: "Weapons",
            genre: "Action",
            description: "An intense action-packed story of survival, betrayal, and redemption with high stakes battles.",
            imageURL: "https://tse3.mm.bing.net/th/id/OIP.Yt4521tTHFVMUy3LJmkrTgHaJQ?pid=Api&P=0&h=180"
        ),
        Movie(
            title: "Superman",
            genre: "Superhero",
            description: "Clark Kent, a mild-mannered reporter, discovers his superhuman abilities and takes on the responsibility of protecting Earth as Superman.",
            imageURL: "https://tse1.mm.bing.net/th/id/OIP.hgq-qqoaLflO-Qyqi30scgHaJP?pid=Api&P=0&h=180"
        ),
        Movie(
            title: "F1 : The Movie",
            genre: "Sports",
            description: "A high-octane film that immerses viewers in the world of Formula 1 racing, filled with drama, rivalries, and speed.",
            imageURL: "https://image.tmdb.org/t/p/original/vqBmyAj0Xm9LnS1xe1MSlMAJyHq.jpg"
        )
    ]
    
    // 🔎 Filtered movies based on search text
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return movies
        } else {
            return movies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.purple.opacity(0.6),
                                        .pink.opacity(0.6),
                                        .blue.opacity(0.5)],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                .ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        
                        // App Title
                        Text("UCFlix 🍿")
                            .font(.largeTitle.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal)
                            .padding(.top, 20)
                        
                        // 🔎 Search Bar
                        HStack {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)
                            TextField("Search for movies", text: $searchText)
                                .textFieldStyle(PlainTextFieldStyle())
                                .foregroundColor(.white)
                        }
                        .padding()
                        .background(Color.white.opacity(0.25))
                        .cornerRadius(12)
                        .padding(.horizontal)
                        
                        // 🍿 Popular Section
                        Text("Popular")
                            .font(.title2.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal)
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(filteredMovies) { movie in
                                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                                        MovieCard(movie: movie, width: 140, height: 200)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        
                        // 🎬 Recommended Section
                        Text("Recommended")
                            .font(.title2.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal)
                        
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())],
                                  spacing: 16) {
                            ForEach(filteredMovies) { movie in
                                NavigationLink(destination: MovieDetailView(movie: movie)) {
                                    MovieCard(movie: movie, width: 170, height: 180)
                                }
                            }
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 80)
                    }
                }
            }
        }
    }
}
