//
//  ContentView.swift
//  W04_Anne
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       HomeView()
    }
    
}

#Preview {
    ContentView()
}
