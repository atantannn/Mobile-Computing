//  MovieDetail.swift
//  W04_Anne
//
//  Created by student on 02/10/25.
//
import SwiftUI
struct MovieDetailView: View {
    let movie: Movie
    @State private var isFavorite = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
          
                AsyncImage(url: URL(string: movie.imageURL)) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(height: 250)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(15)
                            .shadow(radius: 8)
                    case .failure(_):
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.red.opacity(0.3))
                            .frame(height: 250)
                    @unknown default:
                        EmptyView()
                    }
                }
                .padding()
                
          
                Text(movie.title)
                    .font(.largeTitle.bold())
                
             
                Text(movie.genre)
                    .font(.title2)
                    .foregroundColor(.secondary)
          
                Text(movie.description)
                    .font(.body)
                    .foregroundColor(.primary)
                    .padding(.horizontal)
                
                Spacer()
            }
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
#Preview {
    MovieDetailView(
        movie: Movie(
            title: "Encanto",
            genre: "Animation",
            description: "Encanto tells the tale of an extraordinary family, the Madrigals, who live hidden in the mountains of Colombia in a magical house.",
            imageURL: "https://tse3.mm.bing.net/th/id/OIP.Yt4521tTHFVMUy3LJmkrTgHaJQ?pid=Api&P=0&h=180"
        )
    )
}
