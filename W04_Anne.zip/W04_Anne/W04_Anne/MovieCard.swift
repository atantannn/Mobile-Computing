//
//  MovieCard.swift
//  W04_Anne
//
//  Created by student on 02/10/25.
//
import SwiftUI
struct MovieCard: View {
    let movie: Movie
    var width: CGFloat = 140
    var height: CGFloat = 200
    
    var body: some View {
        VStack(alignment: .leading) {
            AsyncImage(url: URL(string: movie.imageURL)) { phase in
                switch phase {
                case .empty:
                    ZStack {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color.gray.opacity(0.3))
                            .frame(width: width, height: height)
                        ProgressView()
                    }
                case .success(let image):
                    image
                        .resizable()
                        .scaledToFill()
                        .frame(width: width, height: height)
                        .cornerRadius(16)
                        .shadow(radius: 5)
                case .failure(_):
                    ZStack {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color.red.opacity(0.3))
                            .frame(width: width, height: height)
                        Image(systemName: "exclamationmark.triangle")
                            .foregroundColor(.red)
                    }
                @unknown default:
                    EmptyView()
                }
            }
            
            Text(movie.title)
                .font(.headline)
                .foregroundColor(.white)
                .padding(.top, 5)
        }
    }
}
