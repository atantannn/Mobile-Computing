//
//  W04_AnneApp.swift
//  W04_Anne
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_AnneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
