//
//  W02_AnneTests.swift
//  W02_AnneTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Anne

struct W02_AnneTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
