//
//  W02_AnneApp.swift
//  W02_Anne
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_AnneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
