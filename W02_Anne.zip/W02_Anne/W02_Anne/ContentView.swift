//
//  ContentView.swift
//  W02_Anne
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    //Declare Variable
    @State private var point = 80
    @State private var isOn: Bool = false
    @State private var volume: Double = 0.5
    @State private var name: String = ""
    private func actionButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(title, action:action)
            .padding(.horizontal, 16).padding(.vertical, 10)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
    }
    private func progressCard(score: Int)-> some View{
        VStack(){
            Text("Current Score").font(.headline)
            ProgressView(value: Double(score), total:100)
            Text("\(score)/100")
                .foregroundStyle(.secondary)
               
        }
        .padding()
        .background(.green.opacity(0.5))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
    let fruits = ["Apple", "Orange", "Banana"]
    var body: some View {
        List(fruits, id: \.self) {
            fruit in HStack{
                Text(fruit)
                Spacer()
                Text("u u a a")
            }
        }
        //Container
//        VStack(spacing:8){
//            
//            Text("Anne")
//            Text("Surabaya")
//            Text("anne")
//            Spacer() //akan memenuhi containernya
//            
//                
//            }
//        VStack{
//            Toggle("Enable Notifications", isOn: $isOn)
//                .padding()
//            Text(isOn ? "Hore" : "Yahh")
//            
//            Slider(value: $volume, in: 0...1)
//            Text("Volume sekarang : \(volume)%")
//            
//            TextField("Namamu siapa", text: $name).textFieldStyle(.roundedBorder)
//                .padding()
//            Text("HEELAUR \(name)!")
//            Text(name == "" ? "Hai" : "Hello \(name)!")
//        }
        VStack{
            progressCard(score: point)
            HStack{
                actionButton("Add 10"){
                    point+=10}
                actionButton("Reset"){point = 0}
            }
            
        }
//        ZStack{
//            RoundedRectangle(cornerRadius: 20)
//                .fill(.pink)
//                .frame(width: 200, height: 125)
//            HStack{
//            Text("Anne")
//                .foregroundColor(.white)
//                .font(.headline)
//                .padding(.bottom,80)
//                .padding(10)
//                .padding(.trailing,30)
//            VStack{
//                Text("🐶")
//                Text("🍏🥑")
//            }
//            .padding(.top,50)
//        }
//                
////            Circle()
////                .frame(width: 50, height: 50)
////                .opacity(0.2)
//        }
        VStack{
            Text("Shadow Example")
            
                .padding()
                .background(Color.blue)
                .cornerRadius(10)
                .shadow(color:.black, radius: 5, x:-1, y:2)
        }
        .padding()
        .background(.blue.opacity(0.5))
        VStack{
            Button("Tekan saya~") {
                // Event
                print("Saya tertekan")
            }
            .buttonStyle(.borderedProminent)
            .tint(.blue)
//            .foregroundStyle(.white)
//            .padding(10)
//            .background(Color.green)
//            .cornerRadius(20)
            Button("Coba aku"){
                
            }
            .buttonStyle(BorderedButtonStyle())
            .tint(.purple)
        }.padding()
        VStack{
            Image(systemName: "lizard.fill")
                .symbolRenderingMode(.multicolor)
                .font(.system(size: 100))
        }
    }
}

#Preview {
    ContentView()
}
