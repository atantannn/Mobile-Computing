//
//  ContentView.swift
//  W01_Anne
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing:25) {
            HStack {
                Image("Anne")
                    .resizable()
                    .frame(width: 300, height: 200)
                    .clipShape(Circle())
                    .shadow(color: Color.blue.opacity(0.8), radius: 100)
                    .padding(20)
            }
            HStack {
                Text("Hi, I'm Anne")
                    .fontWeight(.bold)
                    .font(.largeTitle)
                    .italic()
                    .foregroundStyle(
                        LinearGradient(colors: [.red, .blue], startPoint: .leading,
                                    endPoint: .trailing)
                    )
            }
            HStack {
                Text("My Age is 20")
                    .font(.headline)
                    .foregroundStyle(.gray)
            }
            HStack {
                Text("💚🇨🇳🧚🏻")
                    .background(.blue.opacity(0.3))
                    .font(.title)
                
            }
            
            
        }
        .padding()
        
    }
}

#Preview {
    ContentView()
}
