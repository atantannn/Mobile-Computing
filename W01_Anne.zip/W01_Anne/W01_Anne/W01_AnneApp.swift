//
//  W01_AnneApp.swift
//  W01_Anne
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W01_AnneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
