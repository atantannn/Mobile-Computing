//
//  W01_AnneTests.swift
//  W01_AnneTests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import W01_Anne

struct W01_AnneTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
