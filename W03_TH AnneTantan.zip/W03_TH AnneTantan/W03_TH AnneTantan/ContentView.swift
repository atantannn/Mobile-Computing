//
//  ContentView.swift
//  W03_TH AnneTantan
//
//  Created by Anne Tantan on 27/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            HomeView()
                .tabItem{
                    Image(systemName: "house")
                    }
            LocationView()
                .tabItem {
                    Image(systemName: "mappin.and.ellipse")
                }
            ChartView()
                .tabItem{
                    Image(systemName: "chart.bar.xaxis.ascending")
                }
            Setting()
                .tabItem {
                    Image(systemName: "gearshape")
                }
        }
        .padding()
    }
    
}
struct HomeView : View {
    var body: some View {
        VStack{
            HStack{
                VStack (alignment: .leading, spacing:5){
                    Text("Good Morning,")
                        .font(.system(.title, design:.serif))
                        .padding()
                    Text("Sucipto")
                        .font(.largeTitle.bold())
                        .padding(.leading)
                }
                Spacer()
                Image("foto")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(10)
            }
            
            TextField("Search", text: .constant(""))
                .padding()
            .background(Color(.systemGray6))       .cornerRadius(12)
            .overlay(
            HStack {
            Spacer()
            Image(systemName: "magnifyingglass")
            .foregroundColor(.gray)
            .padding(.trailing, 10)
                                }
                            )
            .padding(.horizontal)
            TodaysGoal()
            StatCardView()
            Spacer()
        }
    }
        
}
        
struct TodaysGoal : View {
    var body: some View{
        VStack(alignment: .leading, spacing: 15) {
            Text("Today's Goal")
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, alignment: .center)
            
            HStack(spacing: 15) {
                VStack(spacing: 8) {
                    Image(systemName: "figure.run")
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                    Text("4 Miles")
                        .bold()
                        .foregroundColor(.white)
                    Text("@Thames Route")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
                .frame(maxWidth: .infinity, minHeight: 150)
                .background(Color.white.opacity(0.15))
                .cornerRadius(15)
                
               
                VStack(spacing: 8) {
                    Image(systemName: "figure.rower")
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                    Text("2 Miles")
                        .bold()
                        .foregroundColor(.white)
                    Text("@River Lea")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.8))
                }
                .frame(maxWidth: .infinity, minHeight: 150)
                .background(Color.white.opacity(0.15))
                .cornerRadius(15)
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.pink, Color.blue]),
                startPoint: .leading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(20)
        .padding(.horizontal)

        
    }
}
struct Setting : View {
    var body: some View {
        Text("Settings")
    }
}
struct LocationView : View {
    var body: some View {
        Text("Location")
    }
}
struct ChartView : View {
    var body: some View {
        Text("Summary of this week activity")
    }
}

struct StatCard: View {
    var icon: String
    var value: String
    var gradientColor: [Color]
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 28))
                .foregroundStyle(
                LinearGradient(
                colors: gradientColor,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
                                    )
                                )
            
            Text(value)
                .font(.headline)
                .foregroundStyle(Color.black)
        }
        .frame(maxWidth: .infinity, minHeight: 80)
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 3)
    }
}
struct StatCardView: View {
    var body: some View {
        VStack(spacing: 15) {
            HStack(spacing: 15) {
                StatCard(icon: "heart.fill", value: "68 Bpm", gradientColor: [Color.pink, Color.purple])
                StatCard(icon: "flame.fill", value: "100 Kcal", gradientColor: [Color.orange, Color.red])
            }
            
            HStack(spacing: 15) {
                StatCard(icon: "scalemass.fill", value: "73 Kg", gradientColor: [Color.blue, Color.green])
                    .foregroundColor(Color.blue)
                StatCard(icon: "moon.zzz.fill", value: "6.2 Hr", gradientColor:[Color.yellow, Color.orange])
            }
        }
        .padding()
    }
}
    

#Preview {
    ContentView()
}
