//
//  W03_TH_AnneTantanApp.swift
//  W03_TH AnneTantan
//
//  Created by Jennifer Alicia Litan on 27/09/25.
//

import SwiftUI

@main
struct W03_TH_AnneTantanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
